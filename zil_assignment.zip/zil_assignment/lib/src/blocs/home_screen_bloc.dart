import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:rxdart/rxdart.dart';
import 'package:zil_assignment/src/constants/custom_color.dart';
import 'package:zil_assignment/src/models/home_screen_model.dart';

class HomeScreenBloc{
  static Map <String, dynamic> categoryMap={
    "data" : [
            {
            "name" : "Jackets",
            "selected" : false
            },

            {
            "name" : "Fleece",
            "selected" : false
            },

            {
            "name" : "Sweatshirts & Hoodies",
            "selected" : false
            },

            {
            "name" : "Sweaters",
            "selected" : false
            },

            {
            "name" : "Shirts",
            "selected" : false

            },

            {
            "name" : "Pans & Jeans",
            "selected" : false

            },

  ]
  };
  static final List<String> _filterList= ["Show all", "Buy now", "Buy later"];
  static final List<String> _sortByList= ["assets/menu.png", "assets/menu1.png"];
  static final List<Color> _colorList= [
    CustomColor.orangeColor,
    CustomColor.lightBlueColor,
    CustomColor.greenColor,
    CustomColor.darkBlueColor,
    CustomColor.skyBlueColor,
    CustomColor.lightGrey,
    CustomColor.violetColor,
    CustomColor.orangeColor,
    CustomColor.skyBlueColor,
    CustomColor.violetColor,
  ];
  HomeScreenModel c= HomeScreenModel.fromJson(categoryMap);

  BehaviorSubject<List<Category>> _categoryList= BehaviorSubject<List<Category>>();
  BehaviorSubject<int> _filter = BehaviorSubject<int>();
  BehaviorSubject<int> _sortBy = BehaviorSubject<int>();
  BehaviorSubject<List<Color>> _color = BehaviorSubject<List<Color>>();


  getCategoryList(){
     categoryList.sink.add(c.data!);
  }

  setFilter(int index){
    _filter.sink.add(index);
  }

  setSortBy(int index){
    _sortBy.sink.add(index);
  }

  getColorList(){
    _color.sink.add(_colorList);
  }


  dispose(){
   _categoryList.close();
   _filter.close();
   _sortBy.close();
   _color.close();
  }


BehaviorSubject<List<Category>> get categoryList=> _categoryList;

BehaviorSubject<int> get filterIndex => _filter;

BehaviorSubject<int> get sortBy=> _sortBy;

BehaviorSubject<List<Color>> get getColorsList=> _color;

List<String> get filterList => _filterList;

List<String> get sortByList => _sortByList;

}
HomeScreenBloc homeScreenBloc= HomeScreenBloc();