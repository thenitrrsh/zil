import 'package:flutter/material.dart';
import 'package:zil_assignment/src/blocs/home_screen_bloc.dart';
import 'package:zil_assignment/src/constants/custom_color.dart';
import 'package:zil_assignment/src/models/home_screen_model.dart';
import 'package:zil_assignment/src/widgets/ecom_header.dart';
class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {

  @override
  void initState() {
    super.initState();
    homeScreenBloc.getCategoryList();
    homeScreenBloc.setFilter(1);
    homeScreenBloc.setSortBy(1);
    homeScreenBloc.getColorList();
  }
  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
            child: _getBody(context)
          )
      ),
    );
  }

  Widget _getBody(BuildContext context){
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          //header
          const EcommerceHeader(),

          //menuItems
          Padding(
            padding: const EdgeInsets.only(left: 60.0),
            child: menuItemsRow(context),
          ),

          const SizedBox(
            height: 40,
          ),

          //filterContainer
          filterContainer(context)
        ],
      ),
    );
  }

  Row menuItemsRow(BuildContext context){
    double width= MediaQuery.of(context).size.width;
    return Row(
      children: [
        SizedBox(
          height: 40,
          child: Card(
            elevation: 8,
            child: Image.asset("assets/back_arrow.png"),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10)
            ),
          ),
        ),
        const Spacer(),
        SizedBox(
          width: (width * .9) - 100,
          height: 40,
          child: Card(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10)
            ),
            elevation: 8,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 5),
              child: Row(
                children: [
                 textButton("Fast Delivery"),
                  const SizedBox(width: 10,),
                  divider(),
                  textButton("Flower Bouquets"),
                  const SizedBox(width: 10,),
                  divider(),
                  textButton("Cakes"),
                  const SizedBox(width: 10,),
                  divider(), textButton("Gift Bundles"),
                  const SizedBox(width: 10,),
                  divider(),
                  textButton("Personalized"),
                  const SizedBox(width: 10,),
                  divider(),
                  textButton("Create Your Own"),
                  const SizedBox(width: 10,),
                  divider(),

                ],
              ),
            ),
          ),
        )
      ],

    );
  }

  TextButton textButton(String text){
    return TextButton(onPressed: (){}, child: Text(text, style: const TextStyle(
        fontSize: 12,
        color: CustomColor.titleColor,
        fontWeight: FontWeight.bold,
    ),));
  }

  Container divider(){
    return Container(
      width: 1,
      height: 25,
      color: CustomColor.lightGrey2,
    );
  }

  Container filterContainer(BuildContext context){
    double width= MediaQuery.of(context).size.width;
   return  Container(
      margin: const EdgeInsets.only(left: 40 ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text("filters", style: TextStyle( color: CustomColor.blackColor, fontWeight: FontWeight.bold, fontSize: 28),),
              SizedBox(width: 10,),
              Padding(
                padding: EdgeInsets.only(bottom: 5.0),
                child: Text("Clear filters", style: TextStyle( color: CustomColor.clearFilterColor, fontWeight: FontWeight.bold, fontSize: 14, decoration: TextDecoration.underline),),
              ),
              Spacer(),
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 5),
                    width: width/6,
                    height: 25,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(3),
                      color: CustomColor.darkBlueColor.withOpacity(.2)
                    ),
                    child: StreamBuilder<int>(
                      stream: homeScreenBloc.filterIndex.stream,
                      builder: (context, snapshot) {
                        return Center(
                          child: ListView.builder(
                            scrollDirection: Axis.horizontal,
                            itemCount: homeScreenBloc.filterList.length,
                            itemBuilder: (context, index){
                              if(index == snapshot.data){
                                return InkWell(
                                  borderRadius: BorderRadius.circular(2),
                                  onTap: (){
                                    homeScreenBloc.setFilter(index);
                                  },
                                  child: SizedBox(
                                    height: 25,
                                    child: Card(
                                      margin: EdgeInsets.zero,
                                      shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(2),
                                      ),
                                      child: Padding(
                                        padding: const EdgeInsets.symmetric(horizontal: 5.0),
                                        child: Center(
                                          child: Text(
                                            homeScreenBloc.filterList[index],
                                            style: const TextStyle(
                                              color: CustomColor.lightBlueColor,
                                              fontSize: 11
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                );
                              }
                              return Padding(
                                padding: const EdgeInsets.symmetric(horizontal: 5),
                                child: InkWell(
                                  onTap: (){
                                    homeScreenBloc.setFilter(index);
                                  },
                                  child: Center(
                                    child: Text(
                                      homeScreenBloc.filterList[index],
                                      style: TextStyle(
                                        fontSize: 11
                                      ),
                                    ),
                                  ),
                                ),
                              );
                            },
                          ),
                        );
                      }
                    ),
                  ),
                  SizedBox(width: 30,),
                  Container(
                    width: 52,
                    height: 25,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(3),
                        color: CustomColor.darkBlueColor.withOpacity(.2)
                    ),
                    child: StreamBuilder<int>(
                        stream: homeScreenBloc.sortBy.stream,
                        builder: (context, snapshot) {
                          return Center(
                            child: ListView.builder(
                              scrollDirection: Axis.horizontal,
                              itemCount: homeScreenBloc.sortByList.length,
                              itemBuilder: (context, index){
                                List<String> sortBy= homeScreenBloc.sortByList;
                                if(index == snapshot.data){
                                  return InkWell(
                                    borderRadius: BorderRadius.circular(2),
                                    onTap: (){
                                      homeScreenBloc.setSortBy(index);
                                    },
                                    child: SizedBox(
                                      height: 25,
                                      child: Card(
                                        margin: EdgeInsets.zero,
                                        shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(2),
                                        ),
                                        child: Padding(
                                          padding: const EdgeInsets.symmetric(horizontal: 5.0),
                                          child: Center(
                                            child: Image.asset(sortBy[index]),
                                          ),
                                        ),
                                      ),
                                    ),
                                  );
                                }
                                return Padding(
                                  padding: const EdgeInsets.symmetric(horizontal: 5),
                                  child: InkWell(
                                    onTap: (){
                                      homeScreenBloc.setSortBy(index);
                                    },
                                    child: Center(
                                      child: Image.asset(sortBy[index]),
                                    ),
                                  ),
                                );
                              },
                            ),
                          );
                        }
                    ),
                  ),

                ],
              )

            ],
          ),
          const SizedBox(height: 20,),
          const Text("Categories", style: TextStyle( color: CustomColor.blackColor, fontWeight: FontWeight.bold, fontSize: 18),),
          const SizedBox(height: 20,),

          //categories
          StreamBuilder<List<Category>>(
            stream: homeScreenBloc.categoryList.stream,
            builder: (context, snapshot){
              if(snapshot.connectionState ==
                  ConnectionState.waiting){
                return const Text("loading data");
              }

              if(snapshot.hasData){
                List<Category> categoryList= snapshot.data!;
                return SizedBox(
                  height: 200,
                  child: ListView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: categoryList.length,
                    itemBuilder: (context, index){
                      return categoryItem(categoryList[index], index);
                    },
                  ),
                );
              }
              return const SizedBox.shrink();
            },
          ),

          const SizedBox(height: 20,),
          const Text("Color", style: TextStyle( color: CustomColor.blackColor, fontWeight: FontWeight.bold, fontSize: 18),),
          const SizedBox(height: 10,),

          //colorsGrid
          StreamBuilder<List<Color>>(
            stream: homeScreenBloc.getColorsList,
            builder: (context, snapshot){
              if (snapshot.connectionState == ConnectionState.waiting) {
                return Container();
              }
              if(snapshot.hasData){
                return colorItem(snapshot.data!);
              }

              return Container();

            },
          ),

          const Text("Size", style: TextStyle( color: CustomColor.blackColor, fontWeight: FontWeight.bold, fontSize: 18),),
          const SizedBox(height: 10,),
        ],
      ),
    );
  }

  Widget categoryItem(Category item, int index){
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5.0),
      child: Row(
        children: [
          Container(
            height: 20,
            width: 20,
            decoration: BoxDecoration(
              border: Border.all(color: CustomColor.lightGrey),
              borderRadius: BorderRadius.circular(2)
            ),
            child: Transform.scale(
              scale: 1.3,
              child: Checkbox(
                side: BorderSide.none,
                focusColor: Colors.transparent,
                  activeColor: Colors.transparent,
                checkColor: CustomColor.blackColor,
                  value: item.selected, onChanged: (v){
               setState(() {
                 item.selected = !item.selected!;
               });
              }),
            ),
          ),
          const SizedBox(width: 5,),
          Text(item.name!, style: TextStyle(color: CustomColor.blackColor),)
        ],
      ),
    );
  }

  Widget colorItem(List<Color> colorList){
     var delegate = const SliverGridDelegateWithFixedCrossAxisCount(
      crossAxisCount: 5,
      crossAxisSpacing: 2,
      mainAxisSpacing: 2,
    );
     return SizedBox(
      height: 50,
      width: 100,
      child: GridView.builder(
          itemCount: colorList.length,
          gridDelegate: delegate,
          physics: const NeverScrollableScrollPhysics(),
          itemBuilder: (context, index){
            return Container(
              width: 30.0,
              height: 30.0,
              decoration: BoxDecoration(
                color: colorList[index],
                shape: BoxShape.circle,
              ),);
          }),
    );
  }
}
