import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:zil_assignment/src/screens/home_screen.dart';

class MyRouters {
static const String homeScreen= '/home';

static Route<dynamic> generateRoute(RouteSettings settings) {
  switch(settings.name){
    case homeScreen:
      return MaterialPageRoute(builder: (context){
          return const HomeScreen();
      });

    default:
      return MaterialPageRoute(
          settings: const RouteSettings(name: homeScreen),
          builder: (context) {
            return const HomeScreen();
          });
  }
}
}